<?php 
/* utf8-marker = äöüß */ 
################## Data fields ############
$page_data_fields[] = 'url';
$page_data_fields[] = 'last_edit';
$page_data_fields[] = 'description';
$page_data_fields[] = 'keywords';
$page_data_fields[] = 'title';
$page_data_fields[] = 'robots';
$page_data_fields[] = 'heading';
$page_data_fields[] = 'show_heading';
$page_data_fields[] = 'template';
$page_data_fields[] = 'published';
$page_data_fields[] = 'show_last_edit';
$page_data_fields[] = 'linked_to_menu';
$page_data_fields[] = 'header_location';
$page_data_fields[] = 'use_header_location';
$page_data_fields[] = 'sitetitle';
$page_data_fields[] = 'show_sitetitle';

################## Recently deleted ############
$temp_data['url'] = 'News01';
$temp_data['last_edit'] = '1587145009';
$temp_data['description'] = '';
$temp_data['keywords'] = '';
$temp_data['title'] = '';
$temp_data['robots'] = '';
$temp_data['heading'] = '';
$temp_data['show_heading'] = '0';
$temp_data['template'] = '0';
$temp_data['published'] = '1';
$temp_data['show_last_edit'] = '0';
$temp_data['linked_to_menu'] = '0';
$temp_data['header_location'] = '';
$temp_data['use_header_location'] = '0';
$temp_data['sitetitle'] = '';
$temp_data['show_sitetitle'] = '';

################## Page Data ############
$page_data[0]['url'] = 'Welcome_to_CMSimple_5';
$page_data[0]['last_edit'] = '1591877609';
$page_data[0]['description'] = '';
$page_data[0]['keywords'] = '';
$page_data[0]['title'] = '';
$page_data[0]['robots'] = '';
$page_data[0]['heading'] = '';
$page_data[0]['show_heading'] = '0';
$page_data[0]['template'] = '0';
$page_data[0]['published'] = '1';
$page_data[0]['show_last_edit'] = '0';
$page_data[0]['linked_to_menu'] = '1';
$page_data[0]['header_location'] = '';
$page_data[0]['use_header_location'] = '0';
$page_data[0]['csrf_token'] = '58f8e1eb031ac0.01829288';
$page_data[0]['sitetitle'] = '';
$page_data[0]['show_sitetitle'] = '';

//----------
$page_data[1]['url'] = 'Willkommen_bei_CMSimple_5';
$page_data[1]['last_edit'] = '1591878609';
$page_data[1]['description'] = '';
$page_data[1]['keywords'] = '';
$page_data[1]['title'] = '';
$page_data[1]['robots'] = '';
$page_data[1]['heading'] = '';
$page_data[1]['show_heading'] = '';
$page_data[1]['template'] = '';
$page_data[1]['published'] = '';
$page_data[1]['show_last_edit'] = '';
$page_data[1]['linked_to_menu'] = '1';
$page_data[1]['header_location'] = '';
$page_data[1]['use_header_location'] = '';
$page_data[1]['sitetitle'] = '';
$page_data[1]['show_sitetitle'] = '';

//----------
$page_data[2]['url'] = 'Menulevels_and_Headings';
$page_data[2]['last_edit'] = '1586504524';
$page_data[2]['description'] = '';
$page_data[2]['keywords'] = '';
$page_data[2]['title'] = '';
$page_data[2]['robots'] = '';
$page_data[2]['heading'] = '';
$page_data[2]['show_heading'] = '0';
$page_data[2]['template'] = '0';
$page_data[2]['published'] = '1';
$page_data[2]['show_last_edit'] = '0';
$page_data[2]['linked_to_menu'] = '1';
$page_data[2]['header_location'] = '';
$page_data[2]['use_header_location'] = '0';
$page_data[2]['sitetitle'] = '';
$page_data[2]['show_sitetitle'] = '';

//----------
$page_data[3]['url'] = 'Menu_Level_2_-_Page_1';
$page_data[3]['last_edit'] = '1701765272';
$page_data[3]['description'] = '';
$page_data[3]['keywords'] = '';
$page_data[3]['title'] = '';
$page_data[3]['robots'] = '';
$page_data[3]['heading'] = '';
$page_data[3]['show_heading'] = '';
$page_data[3]['template'] = '';
$page_data[3]['published'] = '';
$page_data[3]['show_last_edit'] = '';
$page_data[3]['linked_to_menu'] = '1';
$page_data[3]['header_location'] = '';
$page_data[3]['use_header_location'] = '';
$page_data[3]['sitetitle'] = '';
$page_data[3]['show_sitetitle'] = '';

//----------
$page_data[4]['url'] = 'Menu_Level_3_-_Page_1';
$page_data[4]['last_edit'] = '1701765284';
$page_data[4]['description'] = '';
$page_data[4]['keywords'] = '';
$page_data[4]['title'] = '';
$page_data[4]['robots'] = '';
$page_data[4]['heading'] = '';
$page_data[4]['show_heading'] = '';
$page_data[4]['template'] = '';
$page_data[4]['published'] = '';
$page_data[4]['show_last_edit'] = '';
$page_data[4]['linked_to_menu'] = '1';
$page_data[4]['header_location'] = '';
$page_data[4]['use_header_location'] = '';
$page_data[4]['sitetitle'] = '';
$page_data[4]['show_sitetitle'] = '';

//----------
$page_data[5]['url'] = 'MenuLevel_4_Page';
$page_data[5]['last_edit'] = '1701765328';
$page_data[5]['description'] = '';
$page_data[5]['keywords'] = '';
$page_data[5]['title'] = '';
$page_data[5]['robots'] = '';
$page_data[5]['heading'] = '';
$page_data[5]['show_heading'] = '';
$page_data[5]['template'] = '';
$page_data[5]['published'] = '';
$page_data[5]['show_last_edit'] = '';
$page_data[5]['linked_to_menu'] = '1';
$page_data[5]['header_location'] = '';
$page_data[5]['use_header_location'] = '';
$page_data[5]['sitetitle'] = '';
$page_data[5]['show_sitetitle'] = '';

//----------
$page_data[6]['url'] = 'MenuLevel_5_Page';
$page_data[6]['last_edit'] = '1701765337';
$page_data[6]['description'] = '';
$page_data[6]['keywords'] = '';
$page_data[6]['title'] = '';
$page_data[6]['robots'] = '';
$page_data[6]['heading'] = '';
$page_data[6]['show_heading'] = '';
$page_data[6]['template'] = '';
$page_data[6]['published'] = '';
$page_data[6]['show_last_edit'] = '';
$page_data[6]['linked_to_menu'] = '1';
$page_data[6]['header_location'] = '';
$page_data[6]['use_header_location'] = '';
$page_data[6]['sitetitle'] = '';
$page_data[6]['show_sitetitle'] = '';

//----------
$page_data[7]['url'] = 'MenuLevel_6_Page';
$page_data[7]['last_edit'] = '1586419875';
$page_data[7]['description'] = '';
$page_data[7]['keywords'] = '';
$page_data[7]['title'] = '';
$page_data[7]['robots'] = '';
$page_data[7]['heading'] = '';
$page_data[7]['show_heading'] = '';
$page_data[7]['template'] = '';
$page_data[7]['published'] = '';
$page_data[7]['show_last_edit'] = '';
$page_data[7]['linked_to_menu'] = '1';
$page_data[7]['header_location'] = '';
$page_data[7]['use_header_location'] = '';
$page_data[7]['sitetitle'] = '';
$page_data[7]['show_sitetitle'] = '';

//----------
$page_data[8]['url'] = 'Menu_Level_3_-_Page_2';
$page_data[8]['last_edit'] = '1586420039';
$page_data[8]['description'] = '';
$page_data[8]['keywords'] = '';
$page_data[8]['title'] = '';
$page_data[8]['robots'] = '';
$page_data[8]['heading'] = '';
$page_data[8]['show_heading'] = '';
$page_data[8]['template'] = '';
$page_data[8]['published'] = '';
$page_data[8]['show_last_edit'] = '';
$page_data[8]['linked_to_menu'] = '1';
$page_data[8]['header_location'] = '';
$page_data[8]['use_header_location'] = '';
$page_data[8]['sitetitle'] = '';
$page_data[8]['show_sitetitle'] = '';

//----------
$page_data[9]['url'] = 'Menu_Level_3_-_Page_3';
$page_data[9]['last_edit'] = '1586420062';
$page_data[9]['description'] = '';
$page_data[9]['keywords'] = '';
$page_data[9]['title'] = '';
$page_data[9]['robots'] = '';
$page_data[9]['heading'] = '';
$page_data[9]['show_heading'] = '';
$page_data[9]['template'] = '';
$page_data[9]['published'] = '';
$page_data[9]['show_last_edit'] = '';
$page_data[9]['linked_to_menu'] = '1';
$page_data[9]['header_location'] = '';
$page_data[9]['use_header_location'] = '';
$page_data[9]['sitetitle'] = '';
$page_data[9]['show_sitetitle'] = '';

//----------
$page_data[10]['url'] = 'Menu_Level_2_-_Page_2';
$page_data[10]['last_edit'] = '1586419937';
$page_data[10]['description'] = '';
$page_data[10]['keywords'] = '';
$page_data[10]['title'] = '';
$page_data[10]['robots'] = '';
$page_data[10]['heading'] = '';
$page_data[10]['show_heading'] = '';
$page_data[10]['template'] = '';
$page_data[10]['published'] = '';
$page_data[10]['show_last_edit'] = '';
$page_data[10]['linked_to_menu'] = '1';
$page_data[10]['header_location'] = '';
$page_data[10]['use_header_location'] = '';
$page_data[10]['sitetitle'] = '';
$page_data[10]['show_sitetitle'] = '';

//----------
$page_data[11]['url'] = 'Menu_Level_2_-_Page_3';
$page_data[11]['last_edit'] = '1586419925';
$page_data[11]['description'] = '';
$page_data[11]['keywords'] = '';
$page_data[11]['title'] = '';
$page_data[11]['robots'] = '';
$page_data[11]['heading'] = '';
$page_data[11]['show_heading'] = '';
$page_data[11]['template'] = '';
$page_data[11]['published'] = '';
$page_data[11]['show_last_edit'] = '';
$page_data[11]['linked_to_menu'] = '1';
$page_data[11]['header_location'] = '';
$page_data[11]['use_header_location'] = '';
$page_data[11]['sitetitle'] = '';
$page_data[11]['show_sitetitle'] = '';

//----------
$page_data[12]['url'] = 'Templates_and_Plugins';
$page_data[12]['last_edit'] = '1586507957';
$page_data[12]['description'] = '';
$page_data[12]['keywords'] = '';
$page_data[12]['title'] = '';
$page_data[12]['robots'] = '';
$page_data[12]['heading'] = '';
$page_data[12]['show_heading'] = '';
$page_data[12]['template'] = '';
$page_data[12]['published'] = '';
$page_data[12]['show_last_edit'] = '';
$page_data[12]['linked_to_menu'] = '1';
$page_data[12]['header_location'] = '';
$page_data[12]['use_header_location'] = '';
$page_data[12]['sitetitle'] = '';
$page_data[12]['show_sitetitle'] = '';

//----------
$page_data[13]['url'] = 'Languages';
$page_data[13]['last_edit'] = '1587145953';
$page_data[13]['description'] = '';
$page_data[13]['keywords'] = '';
$page_data[13]['title'] = '';
$page_data[13]['robots'] = '';
$page_data[13]['heading'] = '';
$page_data[13]['show_heading'] = '0';
$page_data[13]['template'] = '0';
$page_data[13]['published'] = '1';
$page_data[13]['show_last_edit'] = '0';
$page_data[13]['linked_to_menu'] = '1';
$page_data[13]['header_location'] = '';
$page_data[13]['use_header_location'] = '0';
$page_data[13]['sitetitle'] = '';
$page_data[13]['show_sitetitle'] = '0';
$page_data[13]['csrf_token'] = '5e91cd479cf824.44743763';

//----------
$page_data[14]['url'] = 'News01';
$page_data[14]['last_edit'] = '1587146578';
$page_data[14]['description'] = '';
$page_data[14]['keywords'] = '';
$page_data[14]['title'] = '';
$page_data[14]['robots'] = '';
$page_data[14]['heading'] = '';
$page_data[14]['show_heading'] = '0';
$page_data[14]['template'] = '0';
$page_data[14]['published'] = '1';
$page_data[14]['show_last_edit'] = '0';
$page_data[14]['linked_to_menu'] = '0';
$page_data[14]['header_location'] = '';
$page_data[14]['use_header_location'] = '0';
$page_data[14]['sitetitle'] = '';
$page_data[14]['show_sitetitle'] = '';

//----------
$page_data[15]['url'] = 'News02';
$page_data[15]['last_edit'] = '1646064737';
$page_data[15]['description'] = '';
$page_data[15]['keywords'] = '';
$page_data[15]['title'] = '';
$page_data[15]['robots'] = '';
$page_data[15]['heading'] = '';
$page_data[15]['show_heading'] = '0';
$page_data[15]['template'] = '0';
$page_data[15]['published'] = '1';
$page_data[15]['show_last_edit'] = '0';
$page_data[15]['linked_to_menu'] = '0';
$page_data[15]['header_location'] = '';
$page_data[15]['use_header_location'] = '0';
$page_data[15]['sitetitle'] = '';
$page_data[15]['show_sitetitle'] = '';

//----------
$page_data[16]['url'] = 'News03';
$page_data[16]['last_edit'] = '1587193079';
$page_data[16]['description'] = '';
$page_data[16]['keywords'] = '';
$page_data[16]['title'] = '';
$page_data[16]['robots'] = '';
$page_data[16]['heading'] = '';
$page_data[16]['show_heading'] = '0';
$page_data[16]['template'] = '0';
$page_data[16]['published'] = '1';
$page_data[16]['show_last_edit'] = '0';
$page_data[16]['linked_to_menu'] = '0';
$page_data[16]['header_location'] = '';
$page_data[16]['use_header_location'] = '0';
$page_data[16]['sitetitle'] = '';
$page_data[16]['show_sitetitle'] = '';

//----------
?>