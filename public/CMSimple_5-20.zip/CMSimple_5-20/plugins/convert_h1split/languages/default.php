<?php // utf-8 Marker: äöü 

	$plugin_tx['convert_content']['headline_plugin']="Plugin convert_h1split";
	$plugin_tx['convert_content']['text_backup_hint']="Make a backup of the whole installation, before you do anything!";
	$plugin_tx['convert_content']['text_config_changed']="You have changed the CMS configuration to h1only_pagesplitting.";
	$plugin_tx['convert_content']['text_config_changed_back1']="You can go back to the old splitting method by leaving the following field blank in the CMS configuration:";
	$plugin_tx['convert_content']['text_config_changed_back2']="Settings => CMS => Use => H1only_pagesplitting:";
	$plugin_tx['convert_content']['text_config_changed_back3']="To the CMS configuration &raquo;";
	$plugin_tx['convert_content']['text_conversion_complete']="Converting to h1only_pagesplitting is complete.";
	$plugin_tx['convert_content']['text_convert_content']="Convert content file (content.php) to ";
	$plugin_tx['convert_content']['text_h1only_pagesplitting']="h1only_pagesplitting";
	$plugin_tx['convert_content']['text_plugin_description']="Now you have to convert your content file (content.php) to the new page-splitting method h1only_pagesplitting. All eventual existing styles, classes and IDs of the main headings of the CMSimple pages will be removed.";
	$plugin_tx['convert_content']['text_usage_hint']="Do not use this functions on public websites!";
	$plugin_tx['convert_content']['utf8_marker']="äöü";

?>