<?php // utf-8 Marker: äöü 

	$plugin_tx['convert_content']['headline_plugin']="Plugin convert_h1split";
	$plugin_tx['convert_content']['text_backup_hint']="Machen Sie ein Backup der gesamten Installation, bevor Sie irgendetwas tun!";
	$plugin_tx['convert_content']['text_config_changed']="Sie haben die CMS Konfiguration auf h1only_pagesplitting umgestellt.";
	$plugin_tx['convert_content']['text_config_changed_back1']="Sie können zur alten Splitting Methode zurückkehren, indem Sie in der CMS Konfiguration das folgende Feld leer lassen:";
	$plugin_tx['convert_content']['text_config_changed_back2']="Einstellungen => CMS => Use => H1only_pagesplitting:";
	$plugin_tx['convert_content']['text_config_changed_back3']="Zur CMS Konfiguration &raquo;";
	$plugin_tx['convert_content']['text_conversion_complete']="Die Konvertierung zu h1only_pagesplitting ist komplett.";
	$plugin_tx['convert_content']['text_convert_content']="Konvertiere die Inhaltsdatei (content.php) zu ";
	$plugin_tx['convert_content']['text_h1only_pagesplitting']="h1only_pagesplitting";
	$plugin_tx['convert_content']['text_plugin_description']="Jetzt müssen Sie noch Ihre Inhaltsdatei (content.php) auf die neue Seitensplitting-Methode h1only_pagesplitting umstellen. Dabei werden alle evtl. vorhandenen Styles, Klassen und IDs der Hauptüberschriften der CMSimple Seiten entfernt.";
	$plugin_tx['convert_content']['text_usage_hint']="Verwenden Sie diese Funktionen nicht auf öffentlichen Internetseiten!";
	$plugin_tx['convert_content']['utf8_marker']="äöü";

?>